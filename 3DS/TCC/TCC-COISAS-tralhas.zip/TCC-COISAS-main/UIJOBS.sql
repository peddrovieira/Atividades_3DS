CREATE TABLE Cursos
(
	idCurso INT PRIMARY KEY NOT NULL,
	nomeCurso VARCHAR(70) NOT NULL,
	diplomaCurso CHAR(3) NOT NULL,
);

CREATE TABLE Escolaridade
(
	idEscolaridade INT PRIMARY KEY NOT NULL,
	nomeEscolaridade VARCHAR(50) NOT NULL,
	inicioEscolaridade DATETIME NOT NULL,
	fimEscolaridade DATETIME NOT NULL,
);

CREATE TABLE FormacaoAcademica
(
	idFormacaoAcademica INT PRIMARY KEY NOT NULL,
	idEscolaridade INT NOT NULL,
	idCursos INT NOT NULL,
	CONSTRAINT FK_idEscolaridade_FormacaoAcademica FOREIGN KEY (idEscolaridade)
	REFERENCES Escolaridade (idEscolaridade),
	CONSTRAINT FK_idCursos_FormacaoAcademica FOREIGN KEY (idCursos)
	REFERENCES Cursos (idCurso)
);

CREATE INDEX INDEX_idEscolaridade_FormacaoAcademica ON FormacaoAcademica (idEscolaridade);
CREATE INDEX INDEX_idCursos_FormacaoAcademica ON FormacaoAcademica (idCursos);

CREATE TABLE Curriculo
(
	idCurriculo INT PRIMARY KEY NOT NULL,
	idFormacaoAcademica INT NOT NULL,
	objetivo VARCHAR(200) NOT NULL,
	CONSTRAINT FK_idFormacaoAcademica_Curriculo FOREIGN KEY (idFormacaoAcademica)
	REFERENCES FormacaoAcademica (idFormacaoAcademica),
);

CREATE INDEX INDEX_idFormacaoAcademica_Curriculo ON Curriculo (idFormacaoAcademica);

CREATE TABLE CarreiraProfissional
(
	idCarreiraProfissional INT PRIMARY KEY NOT NULL,
	idCurriculo INT, 
	nomeEmpresa VARCHAR(100),
	tempoInicio DATETIME,
	tempoFim DATETIME,
	cargo VARCHAR(50),
	CONSTRAINT FK_idCurriculo_CarreiraProfissional FOREIGN KEY (idCurriculo)
	REFERENCES Curriculo (idCurriculo)
);

CREATE INDEX INDEX_idCurriculo_CarreiraProfissional ON CarreiraProfissional (idCurriculo);

CREATE TABLE Candidato
(
	idCandidato INT PRIMARY KEY NOT NULL,
	idCurriculo INT NOT NULL,
	nome VARCHAR(60) NOT NULL,
	email VARCHAR(100) NOT NULL,
	foto IMAGE,
	nomeMae VARCHAR(60) NOT NULL,
	CONSTRAINT FK_idCurriculo_Candidato FOREIGN KEY (idCurriculo)
	REFERENCES Curriculo (idCurriculo)	 
);

CREATE INDEX INDEX_idCurriculo_Candidato ON Candidato (idCurriculo);

CREATE TABLE EnderecoCandidato
(
	idEnderecoCandidato INT PRIMARY KEY NOT NULL,
	idCandidato INT NOT NULL,
	cep INT NOT NULL,
	logradouro VARCHAR(15),
	endereco VARCHAR(50),
	numero VARCHAR(5),
	complemento VARCHAR(15),
	bairro VARCHAR(30),
	cidade VARCHAR(50),
	uf CHAR(2),
	CONSTRAINT FK_idCandidato_EnderecoCandidato FOREIGN KEY (idCandidato)
	REFERENCES Candidato (idCandidato)
);

CREATE INDEX INDEX_idCandidato_EnderecoCandidato ON EnderecoCandidato (idCandidato);

CREATE TABLE Portes
(
	idPortes INT PRIMARY KEY NOT NULL,
	tiposPortes VARCHAR(20),
);

CREATE TABLE Empresa
(
	idEmpresa INT NOT NULL,
	idPortes INT NOT NULL,
	cnpj CHAR(18) NOT NULL,
	razaoSocial VARCHAR(50) NOT NULL,
	nomeFantasia VARCHAR(30),
	qtdFuncionarios INT,
	CONSTRAINT FK_idPortes_Empresa FOREIGN KEY (idPortes)
	REFERENCES Portes (idPortes)
);

CREATE INDEX INDEX_idPortes_Empresa ON Empresa (idPortes);

CREATE TABLE EnderecoEmpresa
(
	idEnderecoEmpresa INT PRIMARY KEY NOT NULL,
	idEmpresa INT NOT NULL,
	cep INT NOT NULL,
	logradouro VARCHAR(15) NOT NULL,
	endereco VARCHAR(50) NOT NULL,
	numero VARCHAR(5) NOT NULL,
	complemento VARCHAR(20) NULL,
	bairro VARCHAR(30) NOT NULL,
	cidade VARCHAR(50) NOT NULL,
	uf CHAR(2) NOT NULL,
	CONSTRAINT FK_idEmpresa_EnderecoEmpresa FOREIGN KEY (idEmpresa)
	REFERENCES Empresa (idEmpresa)
);

CREATE INDEX INDEX_idEmpresa_EnderecoEmpresa ON EnderecoEmpresa (idEmpresa);

CREATE TABLE Beneficio (
	idBeneficio INT PRIMARY KEY NOT NULL,
	nomeBeneficio VARCHAR(50) NOT NULL,
);

CREATE TABLE SituacaoVaga (
	idSituacaoVaga INT PRIMARY KEY NOT NULL,
	situacaoAtual VARCHAR(15) NOT NULL
);

CREATE TABLE Vagas (
	idVagas INT PRIMARY KEY NOT NULL,
	idEscolaridade INT NOT NULL,
	idSituacaoVaga INT NOT NULL,
	idEmpresa INT NOT NULL,
	cargo VARCHAR(25),
	descricao VARCHAR(100),
	inicioVigencia DATETIME NOT NULL,
	finalVigencia DATETIME NOT NULL,
	salario FLOAT(15) NOT NULL,
	cargaHoraria INT,
	localidade VARCHAR NOT NULL,
	percAderencia FLOAT(4),
	escalaHorario VARCHAR(40),
	CONSTRAINT FK_idEmpresa_Vagas FOREIGN KEY (idEmpresa)
	REFERENCES Empresa (idEmpresa),
	CONSTRAINT FK_idSituacaoVaga_Vagas FOREIGN KEY (idSituacaoVaga)
	REFERENCES SituacaoVaga (idSituacaoVaga),
	CONSTRAINT FK_idEscolaridade_Vagas FOREIGN KEY (idEscolaridade)
	REFERENCES Escolaridade (idEscolaridade)
);

CREATE TABLE BeneficioVagas (
	idVagas INT PRIMARY KEY NOT NULL,
	idBeneficio INT NOT NULL,
  	CONSTRAINT FK_idBeneficio_BeneficioVagas FOREIGN KEY (idBeneficio)
	REFERENCES Beneficio (idBeneficio),
	CONSTRAINT FK_idVagas_BeneficioVagas FOREIGN KEY (idVagas)
	REFERENCES Vagas (idVagas),
);


CREATE TABLE VagasCandidato (
	idVagas INT PRIMARY KEY NOT NULL,
	idCandidato INT NOT NULL,
	CONSTRAINT FK_idVagas_VagasCandidato FOREIGN KEY (idVagas)
	REFERENCES Vagas (idVagas),
	CONSTRAINT FK_idCandidato_VagasCandidato FOREIGN KEY (idCandidato)
	REFERENCES Candidato (idCandidato),
);

CREATE TABLE Idiomas (
	idIdiomas INT PRIMARY KEY NOT NULL,
	nomeIdioma VARCHAR(15) NOT NULL,
);

CREATE TABLE Nivel (
	idNivel INT PRIMARY KEY NOT NULL,
	idIdiomas INT NOT NULL,
	niveisDisponiveis VARCHAR(20) NOT NULL,
	CONSTRAINT FK_idIdiomas_Nivel FOREIGN KEY (idIdiomas)
	REFERENCES idIdiomas (idIdiomas),
);

CREATE TABLE Conhecimentos (
	idConhecimentos INT PRIMARY KEY NOT NULL,
	idNivel INT NOT NULL,
	nomeConhecimento VARCHAR(30) NOT NULL,
	CONSTRAINT FK_idIdiomas_Conhecimentos FOREIGN KEY (idIdiomas)
	REFERENCES Idiomas (idIdiomas),
	CONSTRAINT FK_idNivel_Conhecimentos FOREIGN KEY (idNivel)
	REFERENCES Nivel (idNivel),
);

CREATE TABLE CurriculoIdiomas (
	idCurriculo INT PRIMARY KEY NOT NULL,
	idIdiomas INT NOT NULL,
	CONSTRAINT FK_idCurriculo_CurriculoIdiomas FOREIGN KEY (idCurriculo)
	REFERENCES Curriculo (idCurriculo),
	CONSTRAINT FK_idIdiomas_CurriculoIdiomas FOREIGN KEY (idIdiomas)
	REFERENCES Idiomas (idIdiomas),
);

CREATE TABLE CurriculoConhecimentos (
	idCurriculo INT PRIMARY KEY NOT NULL,
	idConhecimentos INT NOT NULL,
	CONSTRAINT FK_idCurriculo_CurriculoConhecimentos FOREIGN KEY (idCurriculo)
	REFERENCES Curriculo (idCurriculo),
	CONSTRAINT FK_idConhecimentos_CurriculoConhecimentos FOREIGN KEY (idConhecimentos)
	REFERENCES Conhecimentos (idConhecimentos),
);

CREATE TABLE VagasConhecimentos (
	idVagas INT PRIMARY KEY NOT NULL,
	idConhecimentos INT NOT NULL,
	idNivel INT NOT NULL,
	CONSTRAINT FK_idVagas_VagasConhecimentos FOREIGN KEY (idVagas)
	REFERENCES Vagas (idVagas),
	CONSTRAINT FK_idConhecimentos_VagasConhecimentos FOREIGN KEY (idConhecimentos)
	REFERENCES Conhecimentos (idConhecimentos),
	CONSTRAINT FK_idNivel_VagasConhecimentos FOREIGN KEY (idNivel)
	REFERENCES Nivel (idNivel),
);

CREATE TABLE VagasIdiomas (
	idIdiomas INT PRIMARY KEY NOT NULL,
	idVagas INT NOT NULL,
	CONSTRAINT FK_idVagas_VagasIdiomas FOREIGN KEY (idVagas)
	REFERENCES Vagas (idVagas),
	CONSTRAINT FK_idIdiomas_VagasIdiomas FOREIGN KEY (idIdiomas)
	REFERENCES Idiomas (idIdiomas),
);