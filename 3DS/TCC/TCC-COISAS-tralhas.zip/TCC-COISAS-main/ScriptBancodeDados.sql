CREATE TABLE Beneficio (
  idBeneficio INT NOT NULL AUTO_INCREMENT,
  nomeBeneficio VARCHAR(50) NOT NULL,
  PRIMARY KEY(idBeneficio)
);

CREATE TABLE BeneficioVagas (
  idVagas INT NOT NULL,
  idBeneficio INT NOT NULL,
  PRIMARY KEY(idVagas, idBeneficio),
  INDEX Beneficio_has_Vagas_FKIndex1(idBeneficio),
  INDEX Beneficio_has_Vagas_FKIndex2(idVagas)
);

CREATE TABLE Candidato (
  idCandidato INT NOT NULL AUTO_INCREMENT,
  idCurriculo INT NOT NULL,
  nome VARCHAR(60) NOT NULL,
  email VARCHAR(100) NOT NULL,
  foto IMAGE NULL,
  nomeMae VARCHAR(100) NOT NULL,
  PRIMARY KEY(idCandidato),
  INDEX Candidato_FKIndex1(idCurriculo)
);

CREATE TABLE CarreiraProfissional (
  idCarreiraProfissional INT NOT NULL AUTO_INCREMENT,
  nomeEmpresa VARCHAR(150) NOT NULL,
  tempoInicio DATETIME NOT NULL,
  tempoFim DATETIME NOT NULL,
  cargo VARCHAR(50) NOT NULL,
  PRIMARY KEY(idCarreiraProfissional)
);

CREATE TABLE Conhecimentos (
  idConhecimentos INT NOT NULL AUTO_INCREMENT,
  idNivel INT NOT NULL,
  nomeConhecimento VARCHAR(30) NOT NULL,
  PRIMARY KEY(idConhecimentos),
  INDEX Conhecimentos_FKIndex1(idNivel)
);

CREATE TABLE Curriculo (
  idCurriculo INT NOT NULL AUTO_INCREMENT,
  idFormacaoAcademica INT NOT NULL,
  idCarreiraProfissional INT NOT NULL,
  objetivo VARCHAR(200) NOT NULL,
  PRIMARY KEY(idCurriculo),
  INDEX Curriculo_FKIndex3(idCarreiraProfissional),
  INDEX Curriculo_FKIndex2(idFormacaoAcademica)
);

CREATE TABLE CurriculoConhecimentos (
  idCurriculo INT NOT NULL,
  idConhecimentos INT NOT NULL,
  PRIMARY KEY(idCurriculo, idConhecimentos),
  INDEX Curriculo_has_Conhecimentos_FKIndex1(idCurriculo),
  INDEX Curriculo_has_Conhecimentos_FKIndex2(idConhecimentos)
);

CREATE TABLE CurriculoIdiomas (
  idCurriculo INT NOT NULL,
  idIdiomas INT NOT NULL,
  PRIMARY KEY(idCurriculo, idIdiomas),
  INDEX Curriculo_has_Idiomas_FKIndex1(idCurriculo),
  INDEX Curriculo_has_Idiomas_FKIndex2(idIdiomas)
);

CREATE TABLE Cursos (
  idCursos INT NOT NULL AUTO_INCREMENT,
  nomeCurso VARCHAR(70) NOT NULL,
  diplomaCurso CHAR(3) NOT NULL,
  PRIMARY KEY(idCursos)
);

CREATE TABLE Empresa (
  idEmpresa INT NOT NULL AUTO_INCREMENT,
  idPortes INT NOT NULL,
  cnpj CHAR(18) NOT NULL,
  razaoSocial VARCHAR(50) NOT NULL,
  nomeFantasia VARCHAR(30) NOT NULL,
  qtdFuncionarios INT NULL,
  PRIMARY KEY(idEmpresa),
  INDEX Empresa_FKIndex1(idPortes)
);

CREATE TABLE EnderecoCandidato (
  idEnderecoCandidato INT NOT NULL AUTO_INCREMENT,
  idCandidato INT NOT NULL,
  cep INT(8) NOT NULL,
  logradouro VARCHAR(15) NOT NULL,
  endereco VARCHAR(50) NOT NULL,
  numero VARCHAR(5) NOT NULL,
  complemento VARCHAR(15) NULL,
  bairro VARCHAR(30) NOT NULL,
  cidade VARCHAR(50) NOT NULL,
  uf CHAR(2) NOT NULL,
  PRIMARY KEY(idEnderecoCandidato),
  INDEX EnderecoCandidato_FKIndex1(idCandidato)
);

CREATE TABLE EnderecoEmpresa (
  idEnderecoEmpresa INT NOT NULL AUTO_INCREMENT,
  idEmpresa INT NOT NULL,
  cep INT(8) NOT NULL,
  logradouro VARCHAR(15) NOT NULL,
  endereco VARCHAR(50) NOT NULL,
  numero VARCHAR(5) NOT NULL,
  complemento VARCHAR(20) NULL,
  bairro VARCHAR(30) NOT NULL,
  cidade VARCHAR(50) NOT NULL,
  uf CHAR(2) NOT NULL,
  PRIMARY KEY(idEnderecoEmpresa),
  INDEX EnderecoEmpresa_FKIndex1(idEmpresa)
);

CREATE TABLE Escolaridade (
  idEscolaridade INT NOT NULL AUTO_INCREMENT,
  nomeEscolaridade VARCHAR(50) NOT NULL,
  inicioEscolaridade DATETIME NOT NULL,
  fimEscolaridade DATETIME NOT NULL,
  PRIMARY KEY(idEscolaridade)
);

CREATE TABLE FormacaoAcademica (
  idFormacaoAcademica INT NOT NULL AUTO_INCREMENT,
  idEscolaridade INT NOT NULL,
  idCursos INT NOT NULL,
  PRIMARY KEY(idFormacaoAcademica),
  INDEX FormacaoAcademica_FKIndex1(idCursos),
  INDEX FormacaoAcademica_FKIndex2(idEscolaridade)
);

CREATE TABLE Idiomas (
  idIdiomas INT NOT NULL AUTO_INCREMENT,
  nomeIdioma VARCHAR(15) NOT NULL,
  PRIMARY KEY(idIdiomas)
);

CREATE TABLE Nivel (
  idNivel INT NOT NULL AUTO_INCREMENT,
  idIdiomas INT NOT NULL,
  niveisDisponiveis VARCHAR(20) NOT NULL,
  PRIMARY KEY(idNivel),
  INDEX Nivel_FKIndex1(idIdiomas)
);

CREATE TABLE Portes (
  idPortes INT NOT NULL AUTO_INCREMENT,
  tiposPortes VARCHAR(20) NOT NULL,
  PRIMARY KEY(idPortes)
);

CREATE TABLE SituacaoVaga (
  idSituacaoVaga INT NOT NULL AUTO_INCREMENT,
  situacaoAtual VARCHAR(15) NOT NULL,
  PRIMARY KEY(idSituacaoVaga)
);

CREATE TABLE Vagas (
  idVagas INT NOT NULL AUTO_INCREMENT,
  idEscolaridade INT NOT NULL,
  idSituacaoVaga INT NOT NULL,
  idEmpresa INT NOT NULL,
  cargo VARCHAR(25) NULL,
  descricao VARCHAR(100) NULL,
  inicioVigencia DATETIME NULL,
  finalVigencia DATETIME NULL,
  salario DOUBLE(15) NULL,
  cargaHoraria SMALLINT(2) UNSIGNED NULL,
  localidade VARCHAR NULL,
  percAderencia DOUBLE(4) NULL,
  escalaHorario VARCHAR(40) NULL,
  PRIMARY KEY(idVagas),
  INDEX Vagas_FKIndex1(idEmpresa),
  INDEX Vagas_FKIndex2(idSituacaoVaga),
  INDEX Vagas_FKIndex3(idEscolaridade)
);

CREATE TABLE VagasCandidato (
  idVagas INT NOT NULL,
  idCandidato INT NOT NULL,
  PRIMARY KEY(idVagas, idCandidato),
  INDEX Vagas_has_Candidato_FKIndex1(idVagas),
  INDEX Vagas_has_Candidato_FKIndex2(idCandidato)
);

CREATE TABLE VagasConhecimentos (
  idVagas INT NOT NULL,
  idConhecimentos INT NOT NULL,
  idNivel INT NOT NULL,
  PRIMARY KEY(idVagas, idConhecimentos),
  INDEX Vagas_has_Conhecimentos_FKIndex1(idVagas),
  INDEX Vagas_has_Conhecimentos_FKIndex2(idConhecimentos),
  INDEX VagasConhecimentos_FKIndex3(idNivel)
);

CREATE TABLE VagasIdiomas (
  idIdiomas INT NOT NULL,
  idVagas INT NOT NULL,
  PRIMARY KEY(idIdiomas, idVagas),
  INDEX Vagas_has_Idiomas_FKIndex1(idVagas),
  INDEX Vagas_has_Idiomas_FKIndex2(idIdiomas)
);


